const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// MongoDB
mongoose.connect('mongodb://127.0.0.1:27017/bookingDB')
  .then(() => console.log('MongoDB connected ✅'))
  .catch(err => console.log(err));

// Schema
const bookingSchema = new mongoose.Schema({
  name: String,
  phone: String,
  email: String,
  service: String,
  date: String,
  message: String,
  status: {
    type: String,
    default: "Pending"
  },
  bookedAt: {
    type: String,
    default: () => new Date().toLocaleString()
  }
});

const Booking = mongoose.model('Booking', bookingSchema);

// Test
app.get('/', (req, res) => {
  res.send('Server working 🚀');
});

// CREATE
app.post('/book', async (req, res) => {
  const newBooking = new Booking(req.body);
  await newBooking.save();

  res.json({
    message: "Booking saved 🎉",
    status: newBooking.status
  });
});

// READ
app.get('/bookings', async (req, res) => {
  const data = await Booking.find().sort({ _id: -1 });
  res.json(data);
});

// UPDATE STATUS
app.put('/update/:id', async (req, res) => {
  const { status } = req.body;

  await Booking.findByIdAndUpdate(req.params.id, { status });

  res.json({ message: "Status updated ✅" });
});

// DELETE
app.delete('/delete/:id', async (req, res) => {
  await Booking.findByIdAndDelete(req.params.id);
  res.json({ message: "Deleted 🗑️" });
});

// START
app.listen(3000, () => {
  console.log('Server running on http://localhost:3000 🚀');
});