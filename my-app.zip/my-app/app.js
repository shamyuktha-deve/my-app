document.getElementById('contact-form').addEventListener('submit', function(e) {
  e.preventDefault();

  const data = {
    name: document.getElementById('name').value,
    phone: document.getElementById('phone').value,
    email: document.getElementById('email').value,
    service: document.getElementById('service').value,
    date: document.getElementById('date').value,
    message: document.getElementById('message').value,
    status: "Pending" // default status
  };

  fetch('http://localhost:3000/book', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(data)
  })
  .then(res => res.json())
  .then(data => {
    alert("Booking Sent! Status: Pending ⏳");
  });
});